/*
 * Author: Ireoluwa
 * Created on August 28, 2024, 12:19 PM
 * Purpose: Hello world
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Mathematical, Scientific, Conversions

//Higher Dimensions go here. No Variables

//Function Prototypes

//Execution Begins here

int main(int argc, char** argv) {
    //Setting the random number seed
    
    //Declaring Variables
    
    //Initialize Variables
    
    //Processing/Mapping Inputs to Outputs
    
    //Displaying Input/Output Information
    cout << "Hello World" << endl ;
    
    //Exiting stage left/right
    return 0;
}

