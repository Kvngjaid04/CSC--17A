var _player_stats_8h =
[
    [ "GameRes", "class_game_res.html", "class_game_res" ],
    [ "Stats", "struct_stats.html", "struct_stats" ],
    [ "PStats", "class_p_stats.html", "class_p_stats" ]
];