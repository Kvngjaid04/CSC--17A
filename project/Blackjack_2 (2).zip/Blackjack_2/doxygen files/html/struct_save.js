var struct_save =
[
    [ "funds", "struct_save.html#a59f394a05cbf44ae85e90576e6cb34e2", null ],
    [ "games", "struct_save.html#a590de8d98933b1fa1181b5df23fdf80c", null ],
    [ "gmsAll", "struct_save.html#a66849c66e30e65542ac629864d9b3da9", null ],
    [ "name", "struct_save.html#a87d4df2d25c8c7845cc8e2b31c3cf8c6", null ],
    [ "wins", "struct_save.html#a6645464a8d38439095ec57b31ed264cb", null ],
    [ "winsAll", "struct_save.html#a97a5d9075e6b9d2e4887d08a9815144d", null ]
];