var searchData=
[
  ['player_0',['Player',['../class_player.html',1,'']]],
  ['pstats_1',['PStats',['../class_p_stats.html',1,'']]]
];
