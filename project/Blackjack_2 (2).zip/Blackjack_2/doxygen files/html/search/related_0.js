var searchData=
[
  ['decklogger_0',['DeckLogger',['../class_deck.html#ab94da4fd43709744115e172ef2ee4223',1,'Deck']]]
];
