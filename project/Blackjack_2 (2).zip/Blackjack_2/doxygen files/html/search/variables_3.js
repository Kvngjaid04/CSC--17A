var searchData=
[
  ['hand_0',['hand',['../class_player.html#a120127b3026b271cb7b1a5b82d635503',1,'Player']]]
];
