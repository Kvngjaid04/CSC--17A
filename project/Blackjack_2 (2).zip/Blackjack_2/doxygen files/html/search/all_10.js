var searchData=
[
  ['wanthit_0',['wantHit',['../class_player.html#a395de65d83d94f6298af5b5dabaf9731',1,'Player::wantHit()'],['../class_human.html#aa6cf22859de15a59d14bffeac4a63c5b',1,'Human::wantHit()'],['../class_dealer.html#a832662f2a7de35cdb6c3c68259056278',1,'Dealer::wantHit()']]],
  ['wins_1',['wins',['../struct_stats.html#a535e69c7c041da153082bdd02f79d4c8',1,'Stats::wins'],['../struct_save.html#a6645464a8d38439095ec57b31ed264cb',1,'Save::wins']]],
  ['winsall_2',['winsAll',['../struct_save.html#a97a5d9075e6b9d2e4887d08a9815144d',1,'Save']]]
];
