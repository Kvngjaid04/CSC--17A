var class_human =
[
    [ "Human", "class_human.html#abfd57b90d90f9222384c76b44346ba7b", null ],
    [ "dispHand", "class_human.html#a41589a8a97907c66a633f2aecab9c440", null ],
    [ "wantHit", "class_human.html#aa6cf22859de15a59d14bffeac4a63c5b", null ]
];