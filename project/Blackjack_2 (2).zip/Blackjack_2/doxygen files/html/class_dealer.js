var class_dealer =
[
    [ "Dealer", "class_dealer.html#a518fd02cf57eaf55e06b7754c4649a3f", null ],
    [ "dispHand", "class_dealer.html#aa4a7ca18077f341fe8dfbc3e641de6f6", null ],
    [ "showAll", "class_dealer.html#a6b2d9774b8d0cff1595f38c6f891bf77", null ],
    [ "wantHit", "class_dealer.html#a832662f2a7de35cdb6c3c68259056278", null ]
];