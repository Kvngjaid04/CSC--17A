var hierarchy =
[
    [ "Card", "class_card.html", null ],
    [ "Deck< T >", "class_deck.html", null ],
    [ "Deck< Card >", "class_deck.html", null ],
    [ "Game", "class_game.html", null ],
    [ "GameRes", "class_game_res.html", null ],
    [ "Player", "class_player.html", [
      [ "Dealer", "class_dealer.html", null ],
      [ "Human", "class_human.html", null ]
    ] ],
    [ "PStats", "class_p_stats.html", null ],
    [ "Save", "struct_save.html", null ],
    [ "SaveGame", "class_save_game.html", null ],
    [ "Stats", "struct_stats.html", null ]
];