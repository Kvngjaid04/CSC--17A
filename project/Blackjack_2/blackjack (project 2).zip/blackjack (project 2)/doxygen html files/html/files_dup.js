var files_dup =
[
    [ ".dep.inc", "_8dep_8inc.html", null ],
    [ "BlackJackGame.cpp", "_black_jack_game_8cpp.html", null ],
    [ "BlackJackGame.h", "_black_jack_game_8h.html", "_black_jack_game_8h" ],
    [ "Card.cpp", "_card_8cpp.html", "_card_8cpp" ],
    [ "Card.h", "_card_8h.html", "_card_8h" ],
    [ "Deck.h", "_deck_8h.html", "_deck_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Player.cpp", "_player_8cpp.html", null ],
    [ "Player.h", "_player_8h.html", "_player_8h" ],
    [ "PlayerStats.cpp", "_player_stats_8cpp.html", null ],
    [ "PlayerStats.h", "_player_stats_8h.html", "_player_stats_8h" ],
    [ "SaveGame.cpp", "_save_game_8cpp.html", null ],
    [ "SaveGame.h", "_save_game_8h.html", "_save_game_8h" ]
];