var class_game =
[
    [ "Game", "class_game.html#abb28875d74d25fa9e0dcdbe37c6ad89c", null ],
    [ "operator=", "class_game.html#aead5d069ae11b86a22857d9e7be2f184", null ],
    [ "start", "class_game.html#a3d9b98f7c4a96ecf578f75b96c9f0e90", null ]
];