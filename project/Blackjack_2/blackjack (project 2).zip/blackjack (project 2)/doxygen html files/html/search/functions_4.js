var searchData=
[
  ['human_0',['Human',['../class_human.html#abfd57b90d90f9222384c76b44346ba7b',1,'Human']]]
];
