var searchData=
[
  ['spades_0',['SPADES',['../class_card.html#a5725a8e05afab8cd2f555bd81b069860a46a3bd9b0bb333d0b7521054dd6f8a06',1,'Card']]]
];
