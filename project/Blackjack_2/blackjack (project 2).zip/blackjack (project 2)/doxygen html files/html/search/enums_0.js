var searchData=
[
  ['suit_0',['Suit',['../class_card.html#a5725a8e05afab8cd2f555bd81b069860',1,'Card']]]
];
