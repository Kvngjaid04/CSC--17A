var searchData=
[
  ['game_0',['Game',['../class_game.html',1,'']]],
  ['gameres_1',['GameRes',['../class_game_res.html',1,'']]]
];
