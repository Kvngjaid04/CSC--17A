var searchData=
[
  ['clubs_0',['CLUBS',['../class_card.html#a5725a8e05afab8cd2f555bd81b069860ad85016c04fa090ced22a82729fac4307',1,'Card']]]
];
