var searchData=
[
  ['stats_0',['stats',['../class_player.html#a4d0371e1f41da5ef5cd8a5a761fe5886',1,'Player']]]
];
