var struct_stats =
[
    [ "games", "struct_stats.html#a07ad122885c7965e34b130d8bb886767", null ],
    [ "wins", "struct_stats.html#a535e69c7c041da153082bdd02f79d4c8", null ]
];