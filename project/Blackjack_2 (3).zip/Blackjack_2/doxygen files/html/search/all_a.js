var searchData=
[
  ['name_0',['name',['../class_player.html#acf0355128a99ee20ad9931b760fb2de1',1,'Player::name'],['../struct_save.html#a87d4df2d25c8c7845cc8e2b31c3cf8c6',1,'Save::name']]]
];
