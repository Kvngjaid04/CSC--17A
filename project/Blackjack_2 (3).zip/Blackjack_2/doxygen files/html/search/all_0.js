var searchData=
[
  ['add_0',['add',['../class_p_stats.html#a497ca6c7be75c1cffb6c9887e6182732',1,'PStats']]],
  ['addcard_1',['addCard',['../class_player.html#ad5ff3d1b054718c9e69da62dea18ab01',1,'Player']]],
  ['addgame_2',['addGame',['../class_player.html#a40c5014c6f8ac87b8707c8c611987e9f',1,'Player']]],
  ['addwin_3',['addWin',['../class_player.html#afb68622bbe0d61b7e9c54d21217e0405',1,'Player']]]
];
