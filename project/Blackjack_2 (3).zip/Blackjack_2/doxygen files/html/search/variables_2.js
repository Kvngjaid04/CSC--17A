var searchData=
[
  ['games_0',['games',['../struct_stats.html#a07ad122885c7965e34b130d8bb886767',1,'Stats::games'],['../struct_save.html#a590de8d98933b1fa1181b5df23fdf80c',1,'Save::games']]],
  ['gmsall_1',['gmsAll',['../struct_save.html#a66849c66e30e65542ac629864d9b3da9',1,'Save']]]
];
