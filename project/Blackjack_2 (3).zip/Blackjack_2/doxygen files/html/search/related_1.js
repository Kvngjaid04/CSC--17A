var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_card.html#a3bbd82d9047456c6ecbe51a56ca7a584',1,'Card']]]
];
