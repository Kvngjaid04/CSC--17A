var searchData=
[
  ['funds_0',['funds',['../class_player.html#a38a3243cd8b99085446d1b235cce825c',1,'Player::funds'],['../struct_save.html#a59f394a05cbf44ae85e90576e6cb34e2',1,'Save::funds']]]
];
