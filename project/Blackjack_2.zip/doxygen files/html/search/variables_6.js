var searchData=
[
  ['wins_0',['wins',['../struct_stats.html#a535e69c7c041da153082bdd02f79d4c8',1,'Stats::wins'],['../struct_save.html#a6645464a8d38439095ec57b31ed264cb',1,'Save::wins']]],
  ['winsall_1',['winsAll',['../struct_save.html#a97a5d9075e6b9d2e4887d08a9815144d',1,'Save']]]
];
