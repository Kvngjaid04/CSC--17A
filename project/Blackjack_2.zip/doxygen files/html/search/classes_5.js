var searchData=
[
  ['save_0',['Save',['../struct_save.html',1,'']]],
  ['savegame_1',['SaveGame',['../class_save_game.html',1,'']]],
  ['stats_2',['Stats',['../struct_stats.html',1,'']]]
];
