var _save_game_8h =
[
    [ "Save", "struct_save.html", "struct_save" ],
    [ "SaveGame", "class_save_game.html", null ]
];