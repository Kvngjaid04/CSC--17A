var annotated_dup =
[
    [ "Card", "class_card.html", "class_card" ],
    [ "Dealer", "class_dealer.html", "class_dealer" ],
    [ "Deck", "class_deck.html", "class_deck" ],
    [ "Game", "class_game.html", "class_game" ],
    [ "GameRes", "class_game_res.html", "class_game_res" ],
    [ "Human", "class_human.html", "class_human" ],
    [ "Player", "class_player.html", "class_player" ],
    [ "PStats", "class_p_stats.html", "class_p_stats" ],
    [ "Save", "struct_save.html", "struct_save" ],
    [ "SaveGame", "class_save_game.html", null ],
    [ "Stats", "struct_stats.html", "struct_stats" ]
];