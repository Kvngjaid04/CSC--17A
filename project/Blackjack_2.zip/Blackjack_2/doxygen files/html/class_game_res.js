var class_game_res =
[
    [ "GameRes", "class_game_res.html#a52e74b78aaef74ae2aa3968ebdbb2314", null ],
    [ "getAmt", "class_game_res.html#a8e24d2e6c2a3455d6c13c081ad832269", null ],
    [ "isWin", "class_game_res.html#adad8fbe33cfe6f4f8279dee29bd0a3b7", null ]
];